# Public release checklist

Before publishing a release:

- [ ] Test on a clean Windows 10 computer
- [ ] Test on a clean Windows 11 computer
- [ ] Confirm the phone appears as `device` in `adb devices`
- [ ] Confirm `scrcpy` starts successfully
- [ ] Confirm the Android emulator launcher is optional and clearly documented
- [ ] Do not include Google Play Services or Android system images
- [ ] Do not include third-party binaries unless their licenses and notices are included
- [ ] Keep `LICENSE` and `NOTICE.md` in the repository
- [ ] Create a GitHub release with a version tag such as `v0.1.0`
- [ ] Explain that the current release mirrors a physical Android phone; it is not a new Android emulator engine
