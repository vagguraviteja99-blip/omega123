# Third-party software notice

This repository contains the Android Game Emulator Launcher scripts and configuration created for this project.

It does **not** include the Android SDK, Android system images, Google Play Services, or scrcpy binaries.

Users should install third-party software from its official source and comply with its license and terms:

- scrcpy: https://github.com/Genymobile/scrcpy — Apache License 2.0
- Android SDK and Platform Tools: https://developer.android.com/tools/releases/platform-tools — Google Android SDK License Agreement

This launcher is not affiliated with Google, Android, Genymobile, or the developers of any game.
