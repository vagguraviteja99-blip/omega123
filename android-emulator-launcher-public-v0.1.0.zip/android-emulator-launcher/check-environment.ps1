param([string]$EmulatorPath = "")
$ErrorActionPreference = "Stop"

function Find-Emulator([string]$ExplicitPath) {
    if ($ExplicitPath -and (Test-Path $ExplicitPath)) { return (Resolve-Path $ExplicitPath).Path }
    $roots = @($env:ANDROID_HOME, $env:ANDROID_SDK_ROOT, "$env:LOCALAPPDATA\Android\Sdk") | Where-Object { $_ }
    foreach ($root in $roots) {
        $candidate = Join-Path $root "emulator\emulator.exe"
        if (Test-Path $candidate) { return $candidate }
    }
    return $null
}

Write-Host "Android Game Launcher - environment check" -ForegroundColor Cyan
$emulator = Find-Emulator $EmulatorPath
if (-not $emulator) { Write-Host "FAIL: emulator.exe not found." -ForegroundColor Red; exit 1 }
Write-Host "PASS: $emulator" -ForegroundColor Green
$os = Get-CimInstance Win32_OperatingSystem
$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
$computer = Get-CimInstance Win32_ComputerSystem
Write-Host ("OS: {0}" -f $os.Caption)
Write-Host ("CPU: {0}" -f $cpu.Name)
Write-Host ("Logical processors: {0}" -f $cpu.NumberOfLogicalProcessors)
Write-Host ("Installed RAM: {0:N1} GB" -f ($computer.TotalPhysicalMemory / 1GB))
Write-Host "Checking Android acceleration..." -ForegroundColor Yellow
& $emulator -accel-check
Write-Host "Installed AVDs:" -ForegroundColor Yellow
& $emulator -list-avds
