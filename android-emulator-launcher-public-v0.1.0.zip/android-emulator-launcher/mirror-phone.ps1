param([int]$MaxSize = 1280, [int]$MaxFps = 30, [switch]$Fullscreen)
$ErrorActionPreference = "Stop"
if (-not (Get-Command scrcpy -ErrorAction SilentlyContinue)) {
    throw "scrcpy was not found. Install it with: winget install --exact --id Genymobile.scrcpy. Then open a new PowerShell window."
}
$args = @("--max-size", [string]$MaxSize, "--max-fps", [string]$MaxFps)
if ($Fullscreen) { $args += "--fullscreen" }
Write-Host "Starting phone mirroring. Unlock the phone and approve USB debugging if requested." -ForegroundColor Cyan
& scrcpy @args
exit $LASTEXITCODE
