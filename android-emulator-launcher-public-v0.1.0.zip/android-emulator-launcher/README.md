# Android Game Launcher

A small Windows PowerShell launcher for two public use cases:

1. Mirror and control a physical Android phone with scrcpy.
2. Start an Android Virtual Device with Low, Balanced, or High resource settings.

This project is a launcher/configuration layer. It is **not** a new Android emulator engine.

## Physical phone mode

Install scrcpy from the official source using PowerShell:

```powershell
winget install --exact --id Genymobile.scrcpy
```

Close and reopen PowerShell after installation. Enable **USB debugging** on the phone, connect it by USB, unlock it, and approve the debugging prompt.

Check the phone:

```powershell
adb devices
```

Start mirroring:

```powershell
.\mirror-phone.ps1
```

For full screen:

```powershell
.\mirror-phone.ps1 -Fullscreen
```

For a lower-end computer:

```powershell
.\mirror-phone.ps1 -MaxSize 960 -MaxFps 30
```

The game runs on the phone while Windows displays and controls it.

## Android Virtual Device mode

Requirements:

- Windows 10 or Windows 11
- Android SDK and Android Emulator installed
- At least one AVD created in Android Studio
- Intel VT-x or AMD-V enabled
- Windows Hypervisor Platform enabled

Run the environment check:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\check-environment.ps1
```

Start the emulator:

```powershell
.\launch-emulator.ps1 -Profile Low
```

Available profiles:

| Profile | Guest CPU | Guest RAM | Use |
|---|---:|---:|---|
| Low | 2 cores | 2048 MB | Low-end computers |
| Balanced | 4 cores | 4096 MB | General use |
| High | 6 cores | 6144 MB | High-end computers |

## Public distribution

This repository does not include Android SDK files, Android system images, Google Play Services, or scrcpy binaries. Users install those components from their official sources and must follow their licenses.

This launcher code is released under the MIT License. See `LICENSE` and `NOTICE.md`.

## Project status

Version 0.1.0 is an early public preview. The next planned features are a graphical Windows interface, saved game profiles, input mapping, and clearer diagnostic messages.
