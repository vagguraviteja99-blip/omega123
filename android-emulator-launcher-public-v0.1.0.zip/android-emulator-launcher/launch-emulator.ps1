param(
    [ValidateSet("Low", "Balanced", "High")][string]$Profile = "Balanced",
    [string]$AvdName = "",
    [string]$EmulatorPath = "",
    [switch]$NoSnapshot
)
$ErrorActionPreference = "Stop"

function Find-Emulator([string]$ExplicitPath) {
    if ($ExplicitPath -and (Test-Path $ExplicitPath)) { return (Resolve-Path $ExplicitPath).Path }
    $roots = @($env:ANDROID_HOME, $env:ANDROID_SDK_ROOT, "$env:LOCALAPPDATA\Android\Sdk") | Where-Object { $_ }
    foreach ($root in $roots) {
        $candidate = Join-Path $root "emulator\emulator.exe"
        if (Test-Path $candidate) { return $candidate }
    }
    throw "emulator.exe was not found. Install Android Emulator or pass -EmulatorPath."
}

$config = Get-Content (Join-Path $PSScriptRoot "profiles.json") -Raw | ConvertFrom-Json
$settings = $config.$Profile
if (-not $settings) { throw "Profile '$Profile' was not found." }
$emulator = Find-Emulator $EmulatorPath

if (-not $AvdName) {
    $avds = @(& $emulator -list-avds | Where-Object { $_ -and $_.Trim() })
    if ($avds.Count -eq 0) { throw "No AVDs found. Create one in Android Studio first." }
    if ($avds.Count -eq 1) { $AvdName = $avds[0].Trim() }
    else {
        Write-Host "Available AVDs:" -ForegroundColor Cyan
        for ($i = 0; $i -lt $avds.Count; $i++) { Write-Host ("[{0}] {1}" -f ($i + 1), $avds[$i].Trim()) }
        $choice = Read-Host "Choose an AVD number"
        $index = 0
        if (-not [int]::TryParse($choice, [ref]$index) -or $index -lt 1 -or $index -gt $avds.Count) { throw "Invalid AVD selection." }
        $AvdName = $avds[$index - 1].Trim()
    }
}

$args = @("-avd", $AvdName, "-cores", [string]$settings.cpuCores, "-memory", [string]$settings.memoryMb, "-gpu", [string]$settings.gpuMode, "-no-boot-anim")
if ($NoSnapshot) { $args += "-no-snapshot" }
Write-Host "Starting $AvdName with the $Profile profile..." -ForegroundColor Cyan
& $emulator @args
exit $LASTEXITCODE
